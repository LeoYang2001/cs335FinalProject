export const cardSize = 120;
